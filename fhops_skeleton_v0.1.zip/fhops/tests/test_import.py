def test_import():
    import fhops
    assert fhops.__version__ == "0.1.0"
